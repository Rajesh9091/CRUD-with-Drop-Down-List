﻿namespace CurdWithDDL.Controllers
{
    internal class YourDbContext
    {
        public object Products { get; internal set; }
    }
}